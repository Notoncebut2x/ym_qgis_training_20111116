{
  "nodes": [
    {
      "name": "Ayan",
      "group": 1
    },
    {
      "name": "Amanda",
      "group": 1
    },
    {
      "name": "Daniel",
      "group": 1
    },
    {
      "name": "Kolja",
      "group": 1
    },
    {
      "name": "Paul",
      "group": 1
    },
    {
      "name": "Rory",
      "group": 1
    },
    {
      "name": "Violet",
      "group": 1
    },
    
  ],
  "links": [
    {
      "source": 1,
      "target": 0,
      "value": 1
    },
    {
      "source": 2,
      "target": 0,
      "value": 8
    },
    {
      "source": 3,
      "target": 0,
      "value": 10
    },
    {
      "source": 3,
      "target": 2,
      "value": 6
    },
    {
      "source": 4,
      "target": 0,
      "value": 1
    }

  ]
}